﻿namespace GloboTicket.Services.ShoppingBasket.Entities
{
    public enum BasketChangeTypeEnum
    {
        Add, 
        Remove
    }
}