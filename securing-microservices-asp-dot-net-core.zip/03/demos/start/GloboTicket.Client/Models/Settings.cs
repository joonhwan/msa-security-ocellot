﻿using System;

namespace GloboTicket.Web.Models
{
    public class Settings
    {
        public string BasketIdCookieName => "BasketId";
    }
}
