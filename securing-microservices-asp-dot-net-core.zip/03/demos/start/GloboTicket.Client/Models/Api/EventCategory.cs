﻿using System;

namespace GloboTicket.Web.Models.Api
{
    public class EventCategory
    {
        public Guid CategoryId { get; set; }
        public string Name { get; set; }
    }
}
