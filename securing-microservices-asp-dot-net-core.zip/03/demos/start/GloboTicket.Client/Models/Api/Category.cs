﻿using System;

namespace GloboTicket.Web.Models.Api
{
    public class Category
    {          
        public Guid CategoryId { get; set; }
        public string Name { get; set; }
    }
}
