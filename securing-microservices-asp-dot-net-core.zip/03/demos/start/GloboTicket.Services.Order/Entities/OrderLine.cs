﻿namespace GloboTicket.Services.Ordering.Entities
{
    public class OrderLine
    {
    }
}
